This is the Readme file for the directory "tests" of V-USB, a firmware-only
USB driver for AVR microcontrollers.

WHAT IS IN THIS DIRECTORY?
==========================
This directory is for driver development only. It contains tests to check
whether all branches of #ifdef code compile as they should and whether the
code size of the driver increased.


----------------------------------------------------------------------------
(c) 2008 by OBJECTIVE DEVELOPMENT Software GmbH.
http://www.obdev.at/
